<x-default-layout title="Absensi" section_title="Daftar Absensi">
    <!-- Notification -->
    @if (session('success'))
    <div class="rounded-md bg-green-50 p-4 mb-6 border border-green-200">
        <div class="flex">
                <div class="flex-shrink-0">
                    <i class="ph ph-check-circle text-green-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-green-800">{{ session('success') }}</p>
                </div>
                <div class="ml-auto pl-3">
                    <div class="-mx-1.5 -my-1.5">
                        <button type="button" onclick="this.closest('div.bg-green-50').remove()" class="inline-flex rounded-md p-1.5 text-green-500 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                            <span class="sr-only">Dismiss</span>
                            <i class="ph ph-x"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        @endif
        <div>
            <h2 class="text-lg font-semibold mb-4">Tambah Absensi Baru</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                @foreach ($jadwals as $jadwal)
                    <div class="border rounded-md p-4 shadow hover:shadow-md transition">
                        <p><strong>Kelas:</strong> {{ $jadwal->kelas->nama_kelas }}</p>
                        <p><strong>Mata Pelajaran:</strong> {{ $jadwal->mata_pelajaran->nama_mapel }}</p>
                        <a href="{{ route('absensi.create', $jadwal->id) }}" class="inline-block mt-3 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 text-sm">
                            <i class="ph ph-plus mr-1"></i> Tambah Absensi
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
</x-default-layout>