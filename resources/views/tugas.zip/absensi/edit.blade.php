<x-default-layout title="Absensi" section_title="Edit Absensi Pertemuan">
    <div class="max-w-full mx-auto">
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <form action="{{ route('absensi.update') }}" method="POST">
                    @csrf

                    <input type="hidden" name="id_mapel" value="{{ $jadwalId }}">
                    <input type="hidden" name="tanggal" value="{{ $tanggal }}">

                    <!-- Mata Pelajaran (readonly) -->
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Mata Pelajaran</label>
                        <input type="text" readonly class="mt-1 block w-full rounded-md border-gray-300 shadow-sm bg-gray-100"
                            value="{{ $jadwal->firstWhere('id', $jadwalId)?->mata_pelajaran->nama_mapel }} - {{ $jadwal->firstWhere('id', $jadwalId)?->kelas->nama_kelas }}">
                    </div>

                    <!-- Tanggal (readonly) -->
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Tanggal Pertemuan</label>
                        <input type="date" name="tanggal_display" value="{{ $tanggal }}" readonly class="mt-1 block w-full rounded-md border-gray-300 shadow-sm bg-gray-100">
                    </div>

                    <!-- Daftar Siswa dan Absensi -->
                    <div class="border p-4 rounded-md">
                        <h3 class="font-semibold mb-3">Edit Absensi Siswa</h3>
                        @foreach ($absensi as $index => $data)
                            <div class="mb-3">
                                <input type="hidden" name="absensi[{{ $index }}][id]" value="{{ $data->id }}">
                                <input type="hidden" name="absensi[{{ $index }}][id_siswa]" value="{{ $data->id_siswa }}">
                                <label class="block text-sm font-medium text-gray-700">{{ $data->siswa->nama }}</label>
                                <select name="absensi[{{ $index }}][status]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                    @foreach (['Hadir', 'Alpa', 'Izin', 'Sakit'] as $status)
                                        <option value="{{ $status }}" {{ $data->status == $status ? 'selected' : '' }}>{{ $status }}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endforeach
                    </div>

                    <!-- Tombol -->
                    <div class="mt-6 flex justify-end space-x-3">
                        <a href="{{ route('absensi.index') }}" class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50">Batal</a>
                        <button type="submit" class="px-4 py-2 rounded-md text-white bg-sky-600 hover:bg-sky-700">
                            Update Absensi
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-default-layout>
