<x-default-layout title="Input Nilai" section_title="Input Nilai Siswa">
    <form action="{{ route('nilai.store') }}" method="POST">
        @csrf

        <input type="hidden" name="id_jadwal" value="{{ $jadwal->id }}">

        <div class="mb-4">
            <label>Mata Pelajaran</label>
            <input type="text" readonly value="{{ $jadwal->mata_pelajaran->nama_mapel }} - {{ $jadwal->kelas->nama_kelas }}" class="form-input bg-gray-100">
        </div>

        @foreach ($siswa as $index => $s)
            <div class="mb-3">
                <input type="hidden" name="nilai[{{ $index }}][id_siswa]" value="{{ $s->id }}">
                <label>{{ $s->nama }}</label>
                <input type="number" name="nilai[{{ $index }}][nilai]" class="form-input" required min="0" max="100">
            </div>
        @endforeach

        <button type="submit" class="btn btn-primary">Simpan Nilai</button>
    </form>
</x-default-layout>
