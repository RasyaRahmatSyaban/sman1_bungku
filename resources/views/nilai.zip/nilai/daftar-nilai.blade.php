<x-default-layout title="Nilai" section_title="Daftar Nilai Per Pertemuan">
    <div class="grid grid-cols-1 gap-4">
        @foreach ($jadwals as $jadwal)
            <div class="p-4 bg-white shadow rounded">
                <div class="font-semibold">{{ $jadwal->mata_pelajaran->nama_mapel }} - {{ $jadwal->kelas->nama_kelas }}</div>
                <div class="mt-2">
                    <a href="{{ route('nilai.create', $jadwal->id) }}" class="text-green-600 hover:underline mr-4">Input Nilai</a>
                </div>
            </div>
        @endforeach
    </div>
</x-default-layout>
