<x-default-layout title="Nilai" section_title="Daftar Nilai">
    <!-- Notification -->
    @if (session('success'))
        <div class="rounded-md bg-green-50 p-4 mb-6 border border-green-200">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="ph ph-check-circle text-green-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-green-800">{{ session('success') }}</p>
                </div>
                <div class="ml-auto pl-3">
                    <div class="-mx-1.5 -my-1.5">
                        <button type="button" onclick="this.closest('div.bg-green-50').remove()" class="inline-flex rounded-md p-1.5 text-green-500 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                            <span class="sr-only">Dismiss</span>
                            <i class="ph ph-x"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="mb-6">
        <a href="{{ route('nilai.daftar-nilai') }}" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
            <i class="ph ph-plus mr-2"></i>
            Daftar Nilai
        </a>
    </div>
    <table class="table-auto w-full">
        <thead>
            <tr>
                <th>Kelas</th>
                <th>Mata Pelajaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($nilaiGroups as $nilai)
                <tr>
                    <td>{{ $nilai->jadwal->kelas->nama_kelas }}</td>
                    <td>{{ $nilai->jadwal->mata_pelajaran->nama_mapel }}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex justify-end space-x-2">
                                    <a href="{{ route('nilai.daftar-nilai', $nilai->id) }}" class="text-sky-600 hover:text-sky-900 bg-sky-50 hover:bg-sky-100 p-2 rounded-md transition-colors">
                                        <i class="ph ph-eye"></i>
                                    </a>
                                    <a href="{{ route('nilai.edit', ['id_jadwal' => $nilai->id_jadwal, 'tanggal' => $nilai->tanggal]) }}" class="text-yellow-600 hover:text-yellow-900 bg-yellow-50 hover:bg-yellow-100 p-2 rounded-md transition-colors">
                                        <i class="ph ph-note-pencil"></i>
                                    </a>
                                    <form onsubmit="return confirm('Apakah Anda yakin ingin menghapus semua absensi ini?')" method="POST" action="{{ route('nilai.destroy') }}" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <input type="hidden" name="id_jadwal" value="{{ $nilai->id_jadwal }}">
                                        <button type="submit" class="text-red-600 hover:text-red-900 bg-red-50 hover:bg-red-100 p-2 rounded-md transition-colors">
                                            <i class="ph ph-trash-simple"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</x-default-layout>
